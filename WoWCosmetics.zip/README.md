# Cosmetic list:

### Back cosmetics:

- Thunderfury, Blessed Blade of the Windseeker (Legendary one-handed sword)
- Sulfuras, Hand of Ragnaros (Legendary two-handed mace)
- Ashkandi, Greatsword of the Brotherhood (Epic two-handed sword)
- Dark Edge of Insanity (Epic two-handed axe)
- The Untamed Blade (Epic two-handed sword)
- Zin'rokh, Destroyer of Worlds (Epic two-handed sword)
- Elementium Reinforced Bulwark (Epic shield)
- Skullflame Shield (Epic shield)



All rights to models and names are owned by Activision Blizzard

